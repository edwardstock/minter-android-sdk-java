package com.edwardstock.mintermaven;

import network.minter.blockchain.MinterBlockChainApi;
import network.minter.blockchain.models.BCResult;
import network.minter.blockchain.models.Balance;
import network.minter.blockchain.repo.BlockChainAccountRepository;
import network.minter.core.MinterSDK;
import network.minter.core.crypto.MinterAddress;
import network.minter.core.crypto.PrivateKey;
import network.minter.core.internal.exceptions.NativeLoadException;
import network.minter.core.internal.log.StdLogger;
import network.minter.explorer.MinterExplorerApi;
import network.minter.explorer.models.AddressData;
import network.minter.explorer.models.ExpResult;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

public class App {

    public static void main(String[] args) {

        MinterBlockChainApi.initialize("https://minter-node.apps.minter.network", true, new StdLogger());
        AtomicBoolean working = new AtomicBoolean(true);

        try {
            MinterSDK.initialize();
        } catch (NativeLoadException e) {
            e.printStackTrace();
        }
        PrivateKey pk = PrivateKey.fromMnemonic("unusual label drum flee review action panel wagon duty blast hazard oil");

        // init object with your Minter address
        MinterAddress myAddress = new MinterAddress("Mx06431236daf96979aa6cdf470a7df26430ad8efb");

        BlockChainAccountRepository repo = MinterBlockChainApi.getInstance()
                .account();
        Response<BCResult<Balance>> res = null;
        try {
            res = repo.getBalance(myAddress)
                    .execute();

            if(res.body() == null && res.errorBody() != null) {
                System.err.println(res.errorBody().string());
            } else {
                System.out.println(res.body());
            }

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }

        System.exit(0);
    }
}
